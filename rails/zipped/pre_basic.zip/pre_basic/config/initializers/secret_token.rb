# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
PreBasic::Application.config.secret_token = 'e8df55caea7eb4191eef733f8c0c6f72a81b05aae5564c54c959d1ee60351f28fee9b39522b0046b47bca37c0e5655f3bd232270266b201bda8346781f8b04a2'
