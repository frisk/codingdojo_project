# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Basic::Application.config.secret_token = 'faa56c97c19252869046e7cba2b843da96ed1625cf8aed42a7992e5c4ca313bcaedd3f4cfa9a4cbfd7389e750ccd25b8f3babba45e8e6edd770b535dffb1454c'
