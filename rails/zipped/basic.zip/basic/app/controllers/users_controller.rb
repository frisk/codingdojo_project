class UsersController < ApplicationController
  def new
  end

  def index
  	@users = User.all
  	@user_count = 0
  end
end
